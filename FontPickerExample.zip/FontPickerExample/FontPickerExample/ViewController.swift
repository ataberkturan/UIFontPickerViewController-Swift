//
//  ViewController.swift
//  FontPickerExample
//
//  Created by Ataberk Turan on 11/12/2021.
//

import UIKit

class ViewController: UIViewController, UIFontPickerViewControllerDelegate {
    
    @IBOutlet weak var label: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
     
    }

    @IBAction func selectFontButton(_ sender: Any) {
        let fontPicker = UIFontPickerViewController()
        fontPicker.delegate = self
        present(fontPicker, animated: true, completion: nil)
    }
    
    func fontPickerViewControllerDidPickFont(_ viewController: UIFontPickerViewController) {
        guard let descriptor = viewController.selectedFontDescriptor else { return }
        
        let font = UIFont(descriptor: descriptor, size: 30)
        label.font = font
    }
    
    func fontPickerViewControllerDidCancel(_ viewController: UIFontPickerViewController) {
        print("User cancelled the font picking process.")
    }
}

